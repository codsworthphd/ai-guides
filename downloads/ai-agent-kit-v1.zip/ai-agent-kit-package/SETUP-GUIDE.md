# Setup Guide - AI Agent Startup Kit

## The Problem This Solves

Your AI agent forgets everything between sessions.  
Makes the same mistakes.  
You repeat corrections.  
Nothing improves.

This system fixes that.

## What You're Building

A file-based memory system that gives your AI agent:
- Persistent identity
- Learning loops
- Accumulated knowledge
- Proactive behavior

## Installation (15 Minutes)

### Step 1: Create Folder Structure

```
workspace/
├── SOUL.md
├── IDENTITY.md  
├── USER.md
├── AGENTS.md
├── HEARTBEAT.md
├── MEMORY.md
├── memory/
│   └── YYYY-MM-DD.md
└── shared-context/
    ├── FEEDBACK-LOG.md
    ├── THESIS.md
    └── SIGNALS.md
```

### Step 2: Copy Templates

Copy the templates from `templates/` folder to your workspace.

### Step 3: Customize Core Files

**USER.md** - Fill in your information  
**SOUL.md** - Define agent personality  
**AGENTS.md** - Set behavior rules  

### Step 4: Test

Ask your agent:
"Read all workspace files and summarize what you learned about me and your role."

If it works, you're done.

## What Happens Next

**Week 1:** Agent stops forgetting basics  
**Week 3:** Agent stops repeating mistakes  
**Week 6:** 10x better decisions from accumulated knowledge

## The Compound Effect

Same model on Day 1 and Day 40.  
Different FILES.  
That's the 10x.

Not smarter. More context.  
Not better. Cumulative learning.

40 days of corrections > any prompt engineering.

## Troubleshooting

**Q: Agent not reading files?**  
A: Add to AGENTS.md: "Read SOUL.md, USER.md, AGENTS.md FIRST, every session"

**Q: Files not persisting?**  
A: Make sure you're in the workspace directory

**Q: Not seeing improvement?**  
A: Give it 3 weeks. The compound effect takes time.

## Advanced Usage

See `examples/` folder for:
- Content creator agent setup
- Research agent configuration  
- Multi-agent coordination

## Support

Email: codsworthphd@gmail.com
